export interface Cliente {
    id:string;
    nome:string;
    telefone?:string;
}

