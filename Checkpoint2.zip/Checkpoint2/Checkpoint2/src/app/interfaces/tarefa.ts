export interface Tarefa {
    id:string,
    nome:string,
    descricao:string,
    data?:Date
}
