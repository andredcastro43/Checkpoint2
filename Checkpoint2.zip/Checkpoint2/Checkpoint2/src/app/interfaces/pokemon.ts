export interface Pokemon {
    name: string;
    imageUrl:String;
}
