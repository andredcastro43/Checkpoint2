import { Component } from '@angular/core';

@Component({
  selector: 'app-rota',
  standalone: true,
  imports: [],
  templateUrl: './rota.component.html',
  styleUrl: './rota.component.css'
})
export class RotaComponent {

}
